//
//  LoginViewController.swift
//  Inentory App
//
//  Created by Egor Kosmin on 01.12.2017.
//  Copyright © 2017 Egor Kosmin. All rights reserved.
//

import UIKit
import Firebase
class LoginViewController: UIViewController {
    
    let loginTo = "LoginTo"

    @IBOutlet weak var loginTouch: UIButton!
    @IBOutlet weak var loginTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        Auth.auth().addStateDidChangeListener { (auth, user) in
            if user != nil {
                //проеверить тот ли текст вбит в поле user
                self.performSegue(withIdentifier: self.loginTo, sender: nil)
            }
        }
        
    }

    @IBAction func loginTouchButton(_ sender: UIButton) {
        Auth.auth().signIn(withEmail: loginTextField.text!, password: passwordTextField.text!) { (user, error) in
            if user != nil {
                self.performSegue(withIdentifier: self.loginTo, sender: nil)
            }
        }
    }
    @IBAction func registerTouchButton(_ sender: UIButton) {
        let alert = UIAlertController(title: "Register",
                                      message: "Register",
                                      preferredStyle: .alert)
        
        let saveAction = UIAlertAction(title: "Save", style: .default) { action in
            let emailField = alert.textFields![0]
            let passwordField = alert.textFields![1]
            Auth.auth().createUser(withEmail: emailField.text!, password: passwordField.text!, completion: { (user, error) in
                if error != nil {
                    if let errorCode = AuthErrorCode(rawValue: error!._code){
                        switch errorCode {
                        case .weakPassword:
                            print("Введите более сложный пароль!")
                        default:
                            print("Ошибка")
                        }
                    }
                    return
                }
                if user != nil {
                    user?.sendEmailVerification(completion: { (error) in
                        print(error!.localizedDescription)
                    })
                }
            })
        }
        
        let cancelAction = UIAlertAction(title: "Cancel",
                                         style: .default)
        
        alert.addTextField { textEmail in
            textEmail.placeholder = "Enter your email"
        }
        
        alert.addTextField { textPassword in
            textPassword.isSecureTextEntry = true
            textPassword.placeholder = "Enter your password"
        }
        
        alert.addAction(saveAction)
        alert.addAction(cancelAction)
        
        present(alert, animated: true, completion: nil)
    }
}
extension LoginViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == loginTextField {
            passwordTextField.becomeFirstResponder()
        }
        if textField == passwordTextField {
            textField.resignFirstResponder()
            loginTouchButton(loginTouch)
            //self.performSegue(withIdentifier: self.loginTo, sender: nil)
        }
        return true
    }
}
